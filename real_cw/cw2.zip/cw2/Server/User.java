public class User {
    int userid;
    String challenge;
    AuctionItem owneditem;
    TokenInfo tokenInfo;
    String email;
}
