public class AuctionState {
        int itemID;
        String name;
        String description;
        int highestBid;
        int highestBidderID;
    }