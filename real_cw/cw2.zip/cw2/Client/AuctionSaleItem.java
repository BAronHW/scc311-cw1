import java.io.Serializable;

public class AuctionSaleItem implements java.io.Serializable {
 String name;
 String description;
 int reservePrice;

}

